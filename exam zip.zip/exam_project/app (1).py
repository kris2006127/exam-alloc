from flask import Flask, request, redirect, session, render_template
from db import get_db

app = Flask(__name__)

app.secret_key = "exam_secret"


# =====================================================
# HOME
# =====================================================

@app.route("/")
def home():
    return redirect("/login")


# =====================================================
# LOGIN
# =====================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        db = get_db()

        cursor = db.cursor(dictionary=True)

        cursor.execute(
            """
            SELECT *
            FROM admin_users
            WHERE username=%s
            AND password=%s
            """,
            (username, password)
        )

        user = cursor.fetchone()

        cursor.close()
        db.close()

        if user:
            session["admin"] = username
            return redirect("/dashboard")

        return render_template("login.html", error="Invalid username or password")

    return render_template("login.html")


# =====================================================
# DASHBOARD
# =====================================================

@app.route("/dashboard")
def dashboard():

    if "admin" not in session:
        return redirect("/login")

    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT COUNT(*) as total_students FROM students")
    student_count = cursor.fetchone()

    cursor.execute("SELECT COUNT(*) as total_rooms FROM rooms")
    room_count = cursor.fetchone()

    cursor.execute("SELECT COUNT(*) as total_exams FROM exams")
    exam_count = cursor.fetchone()

    cursor.execute("SELECT COUNT(*) as total_allocated FROM v_seating_chart")
    seat_count = cursor.fetchone()

    cursor.close()
    db.close()

    return render_template(
        "dashboard.html",
        students=student_count["total_students"],
        rooms=room_count["total_rooms"],
        exams=exam_count["total_exams"],
        seating=seat_count["total_allocated"]
    )


# =====================================================
# STUDENTS
# =====================================================

@app.route("/students")
def students():

    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT * FROM students")
    rows = cursor.fetchall()

    cursor.close()
    db.close()

    return render_template("students.html", students=rows)

# =====================================================
# ROOMS
# =====================================================

@app.route("/rooms")
def rooms():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT * FROM rooms")
    rows = cursor.fetchall()

    cursor.close()
    db.close()

    return render_template("rooms.html", rooms=rows)


# =====================================================
# EXAMS
# =====================================================

@app.route("/exams")
def exams():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT * FROM exams")
    rows = cursor.fetchall()

    cursor.close()
    db.close()

    return render_template("exams.html", exams=rows)


# =====================================================
# SEATING CHART
# =====================================================

@app.route("/seating")
def seating():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT * FROM v_seating_chart")
    rows = cursor.fetchall()

    cursor.close()
    db.close()

    return render_template("seating.html", seating=rows)


# =====================================================
# ROOM SUMMARY
# =====================================================

@app.route("/summary")
def summary():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT * FROM v_room_summary")
    rows = cursor.fetchall()

    cursor.close()
    db.close()

    return render_template("summary.html", summary=rows)

# =====================================================
# LOGOUT
# =====================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/login")


# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    app.run(debug=True)