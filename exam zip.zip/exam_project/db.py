import mysql.connector


def get_db():

    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="grisha123",
        database="exam_alloc"
    )

    return conn